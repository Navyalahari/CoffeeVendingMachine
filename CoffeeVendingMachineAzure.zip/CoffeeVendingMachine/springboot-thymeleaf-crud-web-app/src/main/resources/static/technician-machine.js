document.addEventListener('DOMContentLoaded', function () {
    const urlParams = new URLSearchParams(window.location.search);
    const location = urlParams.get('location');

    const titleElement = document.getElementById("locationTitle");
    if (titleElement) {
        titleElement.textContent = `Machines at ${location}`;
    }

    fetch(`/api/machines/by-location?location=${location}`)
        .then(response => response.json())
        .then(data => {
            const machineDropdown = document.getElementById('update-machine');
            const machineList = document.getElementById('machineList');
            machineList.innerHTML = '';

            data.forEach(machine => {
                const option = document.createElement('option');
                option.value = machine.machineId;
                option.textContent = machine.machineId;
                machineDropdown.appendChild(option);

                const tempCelsius = (machine.temperature - 273.15).toFixed(2);

                machineList.innerHTML += `
                    <div class="machine-card machine" id="${machine.machineId}">
                        <div class="front">
                            <h3>${machine.machineId}</h3>
                        </div>
                        <div class="back">
                            <h3>${machine.machineId} Details</h3>
                            <p>Temperature: ${tempCelsius}°C</p>
                            <p>Water Level: ${machine.waterLevel}%</p>
                            <p>Coffee Level: ${machine.coffeeLevel}%</p>
                            <p>Milk Level: ${machine.milkLevel}%</p>
                            <p>Sugar Level: ${machine.sugarLevel}%</p>
                            <p>Status: ${machine.status}</p>
                            <p>Floor Number: ${machine.floorNumber}</p>
                        </div>
                    </div>
                `;
            });
        });

    const statusInput = document.getElementById('status');
    const statusDropdown = document.createElement('select');
    statusDropdown.id = 'status';
    ['Working', 'Under Maintenance'].forEach(status => {
        const option = document.createElement('option');
        option.value = status;
        option.textContent = status;
        statusDropdown.appendChild(option);
    });
    statusInput.replaceWith(statusDropdown);
});

document.getElementById('update-machine').addEventListener('change', function () {
    const selectedMachineId = this.value;
    const modal = document.getElementById('update-modal');
    modal.style.display = 'block';

    document.getElementsByClassName('close')[0].onclick = () => modal.style.display = 'none';
    window.onclick = event => { if (event.target == modal) modal.style.display = 'none'; };

    fetch(`/api/machines`)
        .then(response => response.json())
        .then(machines => {
            const machine = machines.find(m => m.machineId === selectedMachineId);
            if (machine) {
                document.getElementById('machineId').value = machine.machineId;
                document.getElementById('floorNumber').value = machine.floorNumber;
                document.getElementById('temperature').value = machine.temperature;
                document.getElementById('water').value = machine.waterLevel;
                document.getElementById('coffee').value = machine.coffeeLevel;
                document.getElementById('milk').value = machine.milkLevel;
                document.getElementById('sugar').value = machine.sugarLevel;
                document.getElementById('status').value = machine.status;
            }
        });
});

document.getElementById('update-button').onclick = function () {
    const machineId = document.getElementById('machineId').value;

    const temperature = parseFloat(document.getElementById('temperature').value);
    const water = parseFloat(document.getElementById('water').value);
    const coffee = parseFloat(document.getElementById('coffee').value);
    const milk = parseFloat(document.getElementById('milk').value);
    const sugar = parseFloat(document.getElementById('sugar').value);
    const status = document.getElementById('status').value;
    const floorNumber = parseInt(document.getElementById('floorNumber').value);

    if ([water, coffee, milk, sugar].some(level => level > 100)) {
        alert("Water, Coffee, Milk, and Sugar levels must not exceed 100%.");
        return;
    }

    fetch(`/api/machines/by-machine-id/${machineId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            temperature,
            waterLevel: water,
            coffeeLevel: coffee,
            milkLevel: milk,
            sugarLevel: sugar,
            status,
            floorNumber
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to update machine");
        }
        return response.json();
    })
    .then(() => {
        document.getElementById('update-modal').style.display = 'none';
        location.reload();
    })
    .catch(error => {
        console.error("Update failed:", error);
        alert("Updated Successfully.");
    });
};
