document.addEventListener("DOMContentLoaded", () => {
    updateDateTime();
    setInterval(updateDateTime, 1000); // Update time every second

    // Fetch logged-in user details
    fetch("/api/users/me")
        .then(res => {
            if (!res.ok) throw new Error("Unauthorized");
            return res.json();
        })
        .then(user => {
            const empId = user.employeeId;

            // Display employee ID in the header
            document.getElementById("profileName").textContent = empId || "Technician";
            document.getElementById("empId").textContent = empId;

            // Attach click listeners to each location link
            document.querySelectorAll(".location").forEach(loc => {
                const locName = loc.dataset.location;

                loc.addEventListener("click", function (e) {
                    e.preventDefault(); // Prevent default anchor behavior

                    // Check if technician has access to the selected location
                    fetch(`/api/technicians/location/${locName}`, {
                        headers: {
                            "employeeId": empId
                        }
                    })
                    .then(res => {
                        if (!res.ok) {
                            return res.text().then(msg => { throw new Error(msg); });
                        }

                        // Redirect to the machine panel for the selected location
                        window.location.href = `/technician-machine?location=${locName}`;

                    })
                    .catch(err => {
                        alert(err.message || "Access denied");
                    });
                });
            });
        })
        .catch(() => {
            // Option 1: Silent redirect
            window.location.href = "/index";

            // Option 2: Custom modal or toast instead of alert
            // showToast("Session expired. Redirecting to login...");
        });

});

// Function to update the current date and time
function updateDateTime() {
    const now = new Date();
    const formatted = now.toLocaleString('en-IN', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    });
    document.getElementById('current-datetime').textContent = formatted;
}

// Logout function
function logout() {
    fetch("/api/users/logout", { method: "POST" })
        .finally(() => {
            localStorage.clear();
            sessionStorage.clear();
            window.location.href = "/index"; // Redirect to home or login page
        });
}
