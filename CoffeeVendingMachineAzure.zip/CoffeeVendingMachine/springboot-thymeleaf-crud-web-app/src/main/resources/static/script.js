document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    login();
  });
});

function login() {
  const employeeId = document.getElementById('employeeId').value;
  const password = document.getElementById('password').value;

  if (!validateEmployeeId(employeeId)) return;

  if (!validatePassword(password)) {
    document.getElementById('error').textContent =
      'Password must be at least 8 characters long and include letters, numbers, and special characters';
    return;
  }

  fetch('http://localhost:8080/api/users/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ employeeId, password })
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('Invalid credentials');
      }
      return response.json();
    })
    .then(user => {
      const role = user?.role?.toUpperCase?.();
      if (!role) {
        document.getElementById('error').textContent = 'User role is missing or invalid.';
        return;
      }

      // Redirect based on role
      if (role === 'ADMIN') {
        window.location.href = '/admin-home';
      } else if (role === 'TECHNICIAN') {
        window.location.href = '/technician-home';
      } else {
        document.getElementById('error').textContent = 'Unauthorized role.';
      }
    })
    .catch(error => {
      console.error('Login error:', error);
      document.getElementById('error').textContent = error.message;
    });
}

function validateEmployeeId(id) {
  const regex = /^\d{7}$/;
  if (!regex.test(id)) {
    document.getElementById('error').textContent =
      'Employee ID must be exactly 7 digits and contain only numbers';
    return false;
  }
  return true;
}

function validatePassword(password) {
  const regex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&]).{8,}$/;
  return regex.test(password);
}
