package net.javaguides.springboot.service;

import net.javaguides.springboot.model.Machine;
import net.javaguides.springboot.model.Users;
import net.javaguides.springboot.model.Technician;
import net.javaguides.springboot.repository.MachineRepository;
import net.javaguides.springboot.repository.UsersRepository;
import net.javaguides.springboot.repository.TechnicianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MachineServiceImpl implements MachineService {

    @Autowired
    private MachineRepository machineRepository;

    @Autowired
    private UsersRepository userRepository;

    @Autowired
    private TechnicianRepository technicianRepository;

    @Autowired
    private NotificationService notificationService;

    @Override
    public List<Machine> getAllMachines() {
        return machineRepository.findAll();
    }

    @Override
    public List<Machine> getMachinesByLocation(String location) {
        return machineRepository.findByLocation(location);
    }

    @Override
    public Machine getMachineByMachineId(String machineId) {
        return machineRepository.findByMachineId(machineId);
    }

    @Override
    public Machine saveMachine(Machine machine) {
        Machine existing = machineRepository.findByMachineId(machine.getMachineId());

        if (existing != null) {
            existing.setTemperature(machine.getTemperature());
            existing.setWaterLevel(machine.getWaterLevel());
            existing.setCoffeeLevel(machine.getCoffeeLevel());
            existing.setMilkLevel(machine.getMilkLevel());
            existing.setSugarLevel(machine.getSugarLevel());
            existing.setStatus(machine.getStatus());
            existing.setFloorNumber(machine.getFloorNumber());
            existing.setLocation(machine.getLocation());
            machine = existing;
        }

        machineRepository.save(machine);

        // Notifications
        if (machine.getTemperature() > 350) {
            double tempC = machine.getTemperature() - 273.15;
            notificationService.createNotification(
                    "⚠️ Temperature is above 350K (" + String.format("%.2f", tempC) + "°C) for Machine ID: " + machine.getMachineId(),
                    machine.getMachineId()
            );
        }

        if (machine.getWaterLevel() < 40) {
            notificationService.createNotification("⚠️ Water level is below 40% for Machine ID: " + machine.getMachineId(), machine.getMachineId());
        }

        if (machine.getCoffeeLevel() < 40) {
            notificationService.createNotification("⚠️ Coffee level is below 40% for Machine ID: " + machine.getMachineId(), machine.getMachineId());
        }

        if (machine.getMilkLevel() < 40) {
            notificationService.createNotification("⚠️ Milk level is below 40% for Machine ID: " + machine.getMachineId(), machine.getMachineId());
        }

        if (machine.getSugarLevel() < 40) {
            notificationService.createNotification("⚠️ Sugar level is below 40% for Machine ID: " + machine.getMachineId(), machine.getMachineId());
        }

        if ("E".equalsIgnoreCase(machine.getStatus())) {
            notificationService.createNotification("⚠️ Machine ID: " + machine.getMachineId() + " is in error state", machine.getMachineId());
        }

        return machine;
    }

    @Override
    public Machine getMachineById(long id) {
        return machineRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteMachineById(long id) {
        machineRepository.deleteById(id);
    }

    @Override
    public Machine assignTechnicianToMachine(Long machineId, String employeeId) {
        Machine machine = machineRepository.findById(machineId).orElse(null);
        if (machine == null) {
            return null;
        }

        // Update User table
        Users user = userRepository.findByEmployeeId(employeeId);
        if (user != null) {
            user.setMachineId(machine.getMachineId());
            userRepository.save(user);
        }

        // Update Technician table
        Technician technician = technicianRepository.findByEmployeeId(employeeId);
        if (technician != null) {
            technician.setMachineId(machine.getMachineId());
            technicianRepository.save(technician);
        }

        return machine;
    }
}
