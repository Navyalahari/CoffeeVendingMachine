// File: MachineRepository.java
package net.javaguides.springboot.repository;

import net.javaguides.springboot.model.Machine;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MachineRepository extends JpaRepository<Machine, Long> {
    List<Machine> findByLocation(String location);
    Machine findByMachineId(String machineId); //  Added
}
