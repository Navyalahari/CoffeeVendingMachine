package net.javaguides.springboot.controller;

import net.javaguides.springboot.model.Technician;
import net.javaguides.springboot.model.Users;
import net.javaguides.springboot.model.Admin;
import net.javaguides.springboot.repository.TechnicianRepository;
import net.javaguides.springboot.repository.UsersRepository;
import net.javaguides.springboot.service.UsersService;
import net.javaguides.springboot.service.AdminService;
import net.javaguides.springboot.DTO.UsersInfoResponse;
import net.javaguides.springboot.DTO.LoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")
public class UsersController {

    @Autowired
    private UsersService userService;

    @Autowired
    private UsersRepository userRepository;

    @Autowired
    private AdminService adminService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private TechnicianRepository technicianRepository;

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody Users user) {
        if (userRepository.findByEmployeeId(user.getEmployeeId()) != null) {
            return ResponseEntity.badRequest().body("User already exists");
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        Users savedUser = userRepository.save(user);

        if ("ADMIN".equalsIgnoreCase(user.getRole())) {
            Admin admin = new Admin();
            admin.setEmployeeId(user.getEmployeeId());
            admin.setLocation(user.getLocation());
            admin.setMachineId(user.getMachineId());
            adminService.register(admin);
        }

        if ("TECHNICIAN".equalsIgnoreCase(user.getRole())) {
            Technician technician = new Technician();
            technician.setEmployeeId(user.getEmployeeId());
            technician.setLocation(user.getLocation());
            technician.setMachineId(user.getMachineId());
            technicianRepository.save(technician);
        }

        return ResponseEntity.ok(savedUser);
    }


    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody LoginRequest loginRequest, HttpServletRequest request) {
        Users user = userService.loginUser(loginRequest.getEmployeeId(), loginRequest.getPassword());
        if (user == null) {
            return ResponseEntity.status(401).body("Invalid credentials");
        }

        request.getSession().setAttribute("employeeId", user.getEmployeeId());
        request.getSession().setAttribute("role", user.getRole());
        request.getSession().setAttribute("location", user.getLocation());



        return ResponseEntity.ok(new UsersInfoResponse(
                user.getEmployeeId(),
                user.getLocation(),
                user.getRole(),
                user.getMachineId()
        ));
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> payload) {
        String employeeId = payload.get("employeeId");
        String newPassword = payload.get("newPassword");

        Users user = userRepository.findByEmployeeId(employeeId);
        if (user == null) {
            return ResponseEntity.badRequest().body("User not found");
        }

        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
        return ResponseEntity.ok("Password updated successfully");
    }

    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(HttpServletRequest request) {
        String employeeId = (String) request.getSession().getAttribute("employeeId");
        if (employeeId == null) {
            return ResponseEntity.status(401).body("User not logged in");
        }

        Users user = userRepository.findByEmployeeId(employeeId);
        if (user == null) {
            return ResponseEntity.status(404).body("User not found");
        }

        return ResponseEntity.ok(user);
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request) {
        request.getSession().invalidate();
        return ResponseEntity.ok("Logged out successfully");
    }

    @GetMapping("/by-machine/{machineId}")
    public ResponseEntity<?> getUsersByMachineId(@PathVariable String machineId) {
        return ResponseEntity.ok(userRepository.findByMachineId(machineId));
    }

}
