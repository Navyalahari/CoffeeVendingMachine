package net.javaguides.springboot.controller;

import java.util.List;

import net.javaguides.springboot.service.MachineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import net.javaguides.springboot.model.Machine;

import javax.servlet.http.HttpServletRequest;

@Controller
public class MachineController {

    @Autowired
    private MachineService machineService;

    // display home page
    @GetMapping("/home")
    public String viewHomePage() {
        return "index";
    }

    // display login page
    @GetMapping("/login")
    public String viewLoginPage() {
        return "index";
    }

    // display register page
    @GetMapping("/register")
    public String viewRegisterPage() {
        return "register";
    }

    // display forget password page
    @GetMapping("/forget-password")
    public String viewForgetPasswordPage() {
        return "forget-password";
    }

    // display admin dashboard
    @GetMapping("/admin")
    public String viewAdminDashboard() {
        return "admin";
    }

    // display technician dashboard
    @GetMapping("/technician")
    public String viewTechnicianDashboard() {
        return "technician";
    }


    @GetMapping("/technician-home")
    public String technicianHome() {
        return "technician-home"; // This should match your HTML or Thymeleaf template\
    }
    @GetMapping("/admin-home")
    public String adminHome(){
        return "admin-home";
    }
    @GetMapping("/slideshow")
    public String slideShow(HttpServletRequest request, Model model) {
        String role = (String) request.getSession().getAttribute("role");
        model.addAttribute("role", role);
        return "slideshow";
    }

    // display admin machines
    @GetMapping("/admin-machine")
    public String viewAdminMachines(@RequestParam("location") String location, Model model) {
        List<Machine> machines = machineService.getMachinesByLocation(location);
        model.addAttribute("machines", machines);
        return "admin-machine";
    }

    // display technician machines
    @GetMapping("/index")
    public String showIndexPage() {
        return "index"; // This will render index.html from templates
    }

    @GetMapping("/technician-machine")
    public String viewTechnicianMachines(@RequestParam("location") String location, HttpServletRequest request, Model model) {
        // Get location from session
        String sessionLocation = (String) request.getSession().getAttribute("location");

        // Check if session is valid
        if (sessionLocation == null) {
            model.addAttribute("error", "Session expired. Please log in again.");
            return "redirect:/login"; // or another appropriate page
        }

        // Check if technician is accessing their own location
        if (!sessionLocation.equalsIgnoreCase(location)) {
            model.addAttribute("error", "Access denied to this location.");
            return "technician"; // or an error page
        }

        // Fetch machines for the location
        List<Machine> machines = machineService.getMachinesByLocation(location);
        model.addAttribute("machines", machines);

        // Return the view
        return "technician-machine"; // This should match your HTML/Thymeleaf file name
    }

    @PostMapping("/saveMachine")
    public String saveMachine(@ModelAttribute("machine") Machine machine) {
        machineService.saveMachine(machine);
        return "redirect:/technician-machine";
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable(value = "id") long id, Model model) {
        Machine machine = machineService.getMachineById(id);
        model.addAttribute("machine", machine);
        return "update_machine";
    }

    @GetMapping("/deleteMachine/{id}")
    public String deleteMachine(@PathVariable(value = "id") long id) {
        machineService.deleteMachineById(id);
        return "redirect:/technician-machine";
    }
}
