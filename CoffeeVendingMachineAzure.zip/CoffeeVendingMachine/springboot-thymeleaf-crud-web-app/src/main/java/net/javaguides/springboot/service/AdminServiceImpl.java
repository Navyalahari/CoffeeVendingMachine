// File: AdminServiceImpl.java
package net.javaguides.springboot.service;

import net.javaguides.springboot.model.Admin;
import net.javaguides.springboot.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Override
    public Admin register(Admin admin) {
        return adminRepository.save(admin);
    }

    @Override
    public Optional<Admin> findByEmployeeId(String employeeId) {
        return adminRepository.findByEmployeeId(employeeId);
    }
}
