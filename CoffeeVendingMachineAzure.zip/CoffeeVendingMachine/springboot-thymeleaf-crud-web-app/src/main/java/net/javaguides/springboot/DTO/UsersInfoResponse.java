package net.javaguides.springboot.DTO;

public class UsersInfoResponse {
    private String employeeId;
    private String location;
    private String role;
    private String machineId;

    public UsersInfoResponse(String employeeId, String location, String role, String machineId) {
            this.employeeId = employeeId;
            this.location = location;
            this.role = role;
            this.machineId = machineId;
    }

    // Getters and setters
    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

}
