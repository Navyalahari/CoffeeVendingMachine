package net.javaguides.springboot.model;

public class TelemetryMessage {
    private String machineId;
    private String status;
    private double temperature;

    // Getters and setters
    public String getMachineId() { return machineId; }

    public void setMachineId(String machineId) { this.machineId = machineId; }

    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }


    public double getTemperature() { return temperature; }
    public void setTemperature(double temperature) { this.temperature = temperature; }
}

