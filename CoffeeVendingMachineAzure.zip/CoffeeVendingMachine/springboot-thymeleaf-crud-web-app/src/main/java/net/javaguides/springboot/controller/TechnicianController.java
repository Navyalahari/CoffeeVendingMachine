package net.javaguides.springboot.controller;

import net.javaguides.springboot.model.Admin;
import net.javaguides.springboot.model.Technician;
import net.javaguides.springboot.model.Users;
import net.javaguides.springboot.repository.TechnicianRepository;
import net.javaguides.springboot.repository.UsersRepository;
import net.javaguides.springboot.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/technicians")
@CrossOrigin(origins = "*")
public class TechnicianController {

    @Autowired
    private TechnicianRepository technicianRepository;

    @Autowired
    private UsersRepository userRepository;

    @Autowired
    private AdminService adminService;

    // Add a new technician
    @PostMapping("/add")
    public ResponseEntity<?> addTechnician(@RequestBody Technician technician) {
        if (technician.getEmployeeId() == null || technician.getEmployeeId().isEmpty()) {
            return ResponseEntity.badRequest().body("Employee ID is required");
        }

        if (technicianRepository.findByEmployeeId(technician.getEmployeeId()) != null) {
            return ResponseEntity.badRequest().body("Technician already exists");
        }

        Technician saved = technicianRepository.save(technician);
        return ResponseEntity.ok(saved);
    }

    // Get all technicians
    @GetMapping
    public ResponseEntity<?> getAllTechnicians() {
        return ResponseEntity.ok(technicianRepository.findAll());
    }

    //  Get technician by employee ID
    @GetMapping("/{employeeId}")
    public ResponseEntity<?> getTechnicianByEmployeeId(@PathVariable String employeeId) {
        Technician technician = technicianRepository.findByEmployeeId(employeeId);
        if (technician == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(technician);
    }

    //  Check if technician has access to a location
    @GetMapping("/location/{location}")
    public ResponseEntity<?> checkLocationAccess(@PathVariable String location, @RequestHeader("employeeId") String employeeId) {
        Technician technician = technicianRepository.findByEmployeeId(employeeId);
        if (technician == null) {
            return ResponseEntity.status(401).body("Technician not found");
        }

        if (!technician.getLocation().equalsIgnoreCase(location)) {
            return ResponseEntity.status(403).body("Access denied: You are only authorized for location " + technician.getLocation());
        }

        return ResponseEntity.ok("Access granted to " + location);
    }

//  Removed syncTechnicianIfNeeded() method

    //  Get technician employeeIds by admin's location
    @GetMapping("/by-admin-location")
    public ResponseEntity<?> getTechniciansByAdminLocation(@RequestHeader("employeeId") String adminEmpId) {
        Optional<Admin> adminOpt = adminService.findByEmployeeId(adminEmpId);
        if (!adminOpt.isPresent()) {

            return ResponseEntity.status(403).body("Invalid admin credentials");
        }

        String location = adminOpt.get().getLocation();

        List<Users> users = userRepository.findByRoleAndLocationIgnoreCase("TECHNICIAN", location);

        List<String> response = users.stream()
                .map(Users::getEmployeeId)
                .collect(Collectors.toList());
        return ResponseEntity.ok(response);
    }

    //  Sync technician from user table if needed
    private void syncTechnicianIfNeeded(String employeeId) {
        Users user = userRepository.findByEmployeeId(employeeId);
        if (user != null && "technician".equalsIgnoreCase(user.getRole())) {
            Technician existing = technicianRepository.findByEmployeeId(employeeId);
            if (existing == null) {
                Technician technician = new Technician();
                technician.setEmployeeId(user.getEmployeeId());
                technician.setLocation(user.getLocation());
                technicianRepository.save(technician);
                System.out.println("Technician synced: " + employeeId);
            }
        }
    }
}
